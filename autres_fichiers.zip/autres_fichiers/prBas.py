from progressbar import ProgressBar

a=1000000
pBar = ProgressBar(maxval=a)

pBar.start()
for i in range(a):
    pBar.update(i)
pBar.finish()
