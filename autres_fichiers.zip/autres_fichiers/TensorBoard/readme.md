TensorBoard X

Installer tensorflow : https://www.tensorflow.org/install/pip :

python3 -m pip install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl


	
Installer tensorboardX :

pip install tensorboardX

	
Tutoriel : https://github.com/lanpa/tensorboardX/blob/master/docs/tutorial.rst




Pour essayer la base : générer les fichiers sources

python3 main.py

puis démarrer le serveur :

tensorboard --logdir runs

Ensuite dans un navigateur aller à http://localhost:6006/


	
Plus de fonctions de tensorboardX:
python3 test.py
