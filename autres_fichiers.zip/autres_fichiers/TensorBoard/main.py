from tensorboardX import SummaryWriter
import torch
import torchvision.utils as vutils
import torchvision.transforms as transforms
from PIL import Image#, ImageOps
import numpy as np
#SummaryWriter encapsulates everything
writer = SummaryWriter('runs/exp-1')
# creates writer object. The log will be saved in 'runs/exp-1'
# writer2 = SummaryWriter()
# #creates writer2 object with auto generated file name, the dir will be
# # something like 'runs/Aug20-17-20-33'
# writer3 = SummaryWriter(comment='3x learning rate')
# #creates writer2 object with auto generated file name, the comment will
# # be appended to the filename. The dir will be something
# # like 'runs/Aug20-17-20-33-3xlearning rate'


img = Image.open('cow_1.png')
x = transforms.ToTensor()(img)
x = vutils.make_grid(x, normalize=True, scale_each=True)


for n in range(1000):
    writer.add_scalar("Courbe d'erreur", pow(n,2), n)
    writer.add_image("Vache", x, n)

# writer.export_scalars_to_json("./all_scalars.json")
writer.close()
