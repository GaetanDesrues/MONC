python3.6 -m pip install --user torch, torchvision
python3.6 -m pip install --user progressbar
