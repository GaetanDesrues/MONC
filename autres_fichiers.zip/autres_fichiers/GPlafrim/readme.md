1. Connexion depuis son ordi

Copier le fichier ConnexionPlafrim, modifier les infos

Lui donner les permissions : chmod +x ConnexionPlafrim

Se connecter à Plafrim : ./ConnexionPlafrim

Puis : ssh plafrim



2. Première utilisation

git clone https://github.com/GaetanDesrues/MONC.git

cd MONC/GPlafrim

chmod +x requirments

./requirments

cd ..



3. Exécuter un code sur la partition mistral

srun -p mistral python3.6 train.py
