#!/usr/bin/python
# -*- coding: utf-8 -*-

import torch.nn.functional as F
from unet import UNet
from imageLoader import *
from lossFiles import *
import torchvision.transforms as transforms
import os
import time
import configparser
from progressbar import ProgressBar, Bar, SimpleProgress
from optionCompil import *

options = OptionCompilation()

# Charge le fichier de configurations
config = configparser.ConfigParser()
config.read("config2.cfg")

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print("Cuda available : ", torch.cuda.is_available(),"  ---  Starting on", device)

model = UNet(in_channels=1, n_classes=2, padding=True, up_mode='upsample').to(device)

# Check si un modèle existe pour reprendre ou commencer l'apprentissage
if (bool(config['Model']['saveModel'])):
    modelSaved = config['Model']['fileName']
    if (os.path.isfile(os.getcwd()+"/model/"+modelSaved)):
        model.load_state_dict(torch.load(os.getcwd()+"/model/"+modelSaved))
    else:
        print("Attention : le modèle n'existe pas encore et va être créé !")

# Optimisateur pour l'algorithme du gradient
# optim = torch.optim.SGD(model.parameters() , lr=0.1)
optim = torch.optim.Adam(model.parameters() , lr=0.0001)

# Objet représentant les données
cows = DataLoader(
    config['Model']['imgPath'],
    config['Model']['maskPath'],
    config['Model']['file'],
    config['Model']['extension'])

# Nombre d'époques
#epochs = int(config['Train']['epochs'])
# Taille du minibatch
#minibatch = int(config['Train']['minibatch'])

## Taille de resize pour uniformiser les donnees
#crop_size = int(config['Model']['crop_size'])

# Taille totale du dataset
len_cows = len(cows)
# Taille du training set
#len_train = int(float(config['Model']['taux_training']) * len_cows)

epochs = options.epochs
len_train = int(float(options.lengthtrain) * len_cows)
crop_size = options.cropsize
minibatch = options.minibatch


#                    ############### TRAIN ###############

model.train()

# Conversion d'image PIL/numpy vers torch tensor
toTorchTensor = transforms.Compose([transforms.ToTensor()])

erreurMiniBatch = []
erreurEpoch = []

# Définition du fichier d'erreurs argument=nom du fichier à aller cherche dans config
lossFile = lossFile(str(config['Train']['lossFile']))

pBarEpochs = ProgressBar(widgets = ['Epoques : ', SimpleProgress(), '   ', Bar()], maxval = epochs).start()
debut = time.time()

for epoch in range(epochs):
    # print(" ----------------  Starting epoch ",epoch," over ",epochs,"  ----------------")
    # pBarEpochs.update(epoch)
    for i in range(int(len_train/minibatch)):
        # print('-- Minibatch ', i)

        z = torch.Tensor(minibatch,1,crop_size,crop_size).zero_() # 3:in_channels
        zy = torch.Tensor(minibatch,crop_size,crop_size).zero_()

        for m in range(minibatch):
            # On parcourt le training set batch par batch
            cow_i = cows[i+m+1]
            # cow_i.ExtractAsPIL() puis resize
            diCow = cow_i.Resize((crop_size, crop_size))

            imageOriginal = diCow['image']
            imageOriginal = ImageOps.grayscale(imageOriginal)
            maskOriginal = diCow['mask']
            maskOriginal = ImageOps.grayscale(maskOriginal)

            X = toTorchTensor(imageOriginal)
            y = toTorchTensor(maskOriginal)
            # print(X.shape, y.shape)

            # Préparation du minibatch
            # z : Tensor (m,3,crop_size,crop_size)
            z[m:]=X # m ème élément : Tensor X
            zy[m:]=y

        # input tensor (minibatch×in_channels×iH×iW)
        X = z.to(device)  # [N, 1, H, W]

        # print("Forward")
        prediction = model(X) # [N, 2, H, W]

        # Si la sortie a des pixels en moins
        n_pi = (crop_size - prediction.shape[2])//2
        zy = zy[:,n_pi:-n_pi,n_pi:-n_pi] # Essayer d'exécuter en commantant pour voir l'erreur

        # Sortie dont les channels/classes sont 0 et 1 (n_classes = 2)
        y = zy.to(device).long()  # [N, H, W] with class indices (0, 1)

        # Calcul de l'erreur
        loss = F.cross_entropy(prediction, y)
        # print("Loss : ",loss.item())
        erreurMiniBatch.append(loss.item())


        # On initialise les gradients à 0 avant la rétropropagation
        optim.zero_grad()

        # print("Backward")
        # Calcule des gradients
        loss.backward()
        # Modification des poids suivant l'algorithme du gradient choisi
        optim.step()

    erreurEpoch.append(loss.item())
    lossFile.addEpochLoss(epoch,loss.item())


fin = time.time()
pBarEpochs.finish()

timer = round((fin - debut)/60, 2)
print(" ------> Temps de l'apprentissage :", timer, "min.")

if (config['Model']['saveModel']):
    path = os.getcwd()+"/model/"+modelSaved
    torch.save(model.state_dict(), path)

lossFile.plotLoss()


# plt.plot(erreurMiniBatch, label="Training")
# plt.title("Loss - Learning curve")
# plt.xlabel("Epochs * minibatch")
# plt.ylabel("Error")
# plt.show()






# # Exemple d'utilisation du dataset:
# vache = cows[1]
# dicVache = vache.Resize((400,400)) # vache.ExtractAsPIL() puis resize
#
# imageOriginal = dicVache['image']
# maskOriginal = dicVache['mask']
# maskOriginal.show() # mask resizé
# imageOriginal.show() # originale après resize
# # print("img : ",imageOriginal.size)
# imageOriginal = np.array(ImageOps.grayscale(imageOriginal))
# # print("img : ",imageOriginal.shape)
# # imageOriginal = imageOriginal.transpose((2,0,1)) # N&B : pas de transpose car size=[H,W]
# # print("img : ",imageOriginal.shape)
# imageOriginal = torch.from_numpy(np.array([imageOriginal])) # Ajouter une dimension
# # print("img : ", imageOriginal.shape) # Format requis pour l'image
# maskOriginal = torch.from_numpy(np.array(maskOriginal, dtype='float64'))
# # print('mask : ', maskOriginal.shape)
#
# vache.Plot('image') # image originale

















#
