var searchData=
[
  ['lossfile',['lossFile',['../classloss_files_1_1loss_file.html',1,'lossFiles']]]
];
